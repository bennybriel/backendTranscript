<?php

namespace App\SaveConfig\Support;
use Exception;
class FieldNotExistException extends Exception
{
    
}